<footer>
    <p>&copy; <?php echo date("Y"); ?> Your Website Name. All rights reserved.</p>
</footer>
